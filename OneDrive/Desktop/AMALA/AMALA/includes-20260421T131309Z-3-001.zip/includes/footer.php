    </main>
    <footer class="footer">
        <div class="footer-container">
            <div class="footer-section">
                <h3>About COFTEA</h3>
                <p>Your premium destination for the finest coffee experience. Crafted with passion, served with excellence.</p>
            </div>
            
            <div class="footer-section">
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="../index.php">Home</a></li>
                    <li><a href="../menu.php">Menu</a></li>
                    <li><a href="../contact.php">Contact Us</a></li>
                    <li><a href="../signin.php">Sign In</a></li>
                </ul>
            </div>

            <div class="footer-section">
                <h3>Contact Info</h3>
                <p>Email: info@coftea.com</p>
                <p>Phone: (555) 123-4567</p>
                <p>Hours: Mon-Fri 7AM-9PM, Sat-Sun 8AM-10PM</p>
            </div>

            <div class="footer-section">
                <h3>Follow Us</h3>
                <div class="social-links">
                    <a href="#" class="social-link">Facebook</a>
                    <a href="#" class="social-link">Instagram</a>
                    <a href="#" class="social-link">Twitter</a>
                </div>
            </div>
        </div>

        <div class="footer-bottom">
            <p>&copy; 2026 COFTEA Coffee Shop. All rights reserved.</p>
        </div>
    </footer>

    <script src="<?php echo str_repeat('../', $pathLevel ?? 0); ?>assets/js/script.js"></script>
</body>
</html>
