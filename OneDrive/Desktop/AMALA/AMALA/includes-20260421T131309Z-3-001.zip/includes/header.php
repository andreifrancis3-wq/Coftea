<?php 
if (session_status() === PHP_SESSION_NONE) {
    session_start(); 
}
$basePath = str_repeat('../', $pathLevel ?? 0); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? $pageTitle . ' - COFTEA' : 'COFTEA Coffee Shop'; ?></title>
    <link rel="stylesheet" href="<?php echo $basePath; ?>assets/css/style.css">
</head>
<body>
    <header class="navbar">
        <div class="navbar-container">
            <!-- Brand Identity -->
            <div class="navbar-brand">
                <h1 class="logo"><a href="<?php echo $basePath; ?>index.php" style="text-decoration:none; color:inherit;">COFTEA</a></h1>
                <p class="tagline">Premium Coffee Experience</p>
            </div>
            
            <!-- Unified Navigation Links -->
            <nav>
                <ul class="navbar-menu nav-links" style="list-style:none; display:flex; align-items:center;">
                    <li><a href="<?php echo $basePath; ?>index.php" class="nav-link">Home</a></li>
                    <li><a href="<?php echo $basePath; ?>menu.php" class="nav-link">Menu</a></li>
                    <li><a href="<?php echo $basePath; ?>contact.php" class="nav-link">Contact</a></li>
                    <!-- Cart is now part of the main list -->
                    <li>
                        <a href="<?php echo $basePath; ?>cart.php" class="nav-link cart-link">
                            🛒 Cart <span class="cart-count" id="cart-count"><?php echo isset($_SESSION['cart']) ? count($_SESSION['cart']) : 0; ?></span>
                        </a>
                    </li>
                </ul>
            </nav>
            
            <!-- Auth Actions -->
            <div class="nav-actions">
                <?php if (isset($_SESSION['user_id'])): ?>
                    <div class="profile-dropdown">
                        <button class="profile-toggle" id="profileToggle">
                            <span class="profile-icon">👤</span>
                            <span class="profile-name"><?php echo htmlspecialchars(substr($_SESSION['user_name'], 0, 15)); ?></span>
                            <span class="dropdown-arrow">▼</span>
                        </button>
                        
                        <div class="profile-menu" id="profileMenu">
                            <div class="profile-menu-header">
                                <p class="welcome-text">Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?>!</p>
                            </div>
                            <a href="<?php echo $basePath; ?>account-info.php" class="profile-menu-item">⚙️ Account Info</a>
                            <a href="<?php echo $basePath; ?>order-history.php" class="profile-menu-item">📦 Order History</a>
                            <div class="profile-menu-divider"></div>
                            <a href="<?php echo $basePath; ?>logout.php" class="profile-menu-item logout-item">🚪 Logout</a>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="navbar-auth">
                        <a href="<?php echo $basePath; ?>signin.php" class="btn btn-secondary btn-sm">Sign In</a>
                        <a href="<?php echo $basePath; ?>create-account.php" class="btn btn-primary btn-sm">Join Now</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </header>
    <main>