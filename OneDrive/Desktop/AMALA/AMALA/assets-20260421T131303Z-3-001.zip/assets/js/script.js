// ==========================================
// COFTEA Coffee Shop - JavaScript Functionality
// ==========================================

document.addEventListener('DOMContentLoaded', function() {
    initializeButtons();
    initializeCart();
    initializeNavigation();
    initializeProfileDropdown();
});

// ==========================================
// BUTTON INTERACTIONS
// ==========================================

function initializeButtons() {
    const buttons = document.querySelectorAll('.btn');
    
    buttons.forEach(button => {
        // Add ripple effect on click
        button.addEventListener('click', function(e) {
            addRipple(e, this);
            this.classList.add('active');
            setTimeout(() => {
                this.classList.remove('active');
            }, 600);
        });

        // Keyboard accessibility
        button.addEventListener('keypress', function(e) {
            if (e.key === 'Enter' || e.key === ' ') {
                this.click();
            }
        });
    });
}

function addRipple(event, button) {
    const ripple = document.createElement('span');
    const rect = button.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    const x = event.clientX - rect.left - size / 2;
    const y = event.clientY - rect.top - size / 2;

    ripple.style.width = ripple.style.height = size + 'px';
    ripple.style.left = x + 'px';
    ripple.style.top = y + 'px';
    ripple.classList.add('ripple');

    // Remove any existing ripples
    const existingRipples = button.querySelector('.ripple');
    if (existingRipples) {
        existingRipples.remove();
    }

    button.appendChild(ripple);
}

// ==========================================
// CART FUNCTIONALITY
// ==========================================

function initializeCart() {
    const quantityBtns = document.querySelectorAll('.quantity-btn');
    
    quantityBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            handleQuantityChange(this);
        });
    });

    // Initialize quantity inputs
    const quantityInputs = document.querySelectorAll('.quantity-input');
    quantityInputs.forEach(input => {
        input.addEventListener('change', function() {
            updateCartTotal();
        });
    });
}

function handleQuantityChange(button) {
    const quantityContainer = button.closest('.cart-quantity');
    const input = quantityContainer.querySelector('.quantity-input');
    let currentValue = parseInt(input.value) || 1;

    if (button.textContent === '+') {
        currentValue++;
    } else if (button.textContent === '-' && currentValue > 1) {
        currentValue--;
    }

    input.value = currentValue;
    updateCartTotal();

    // Trigger change event for backend processing
    const event = new Event('change', { bubbles: true });
    input.dispatchEvent(event);
}

function updateQuantity(productId, newQuantity) {
    // Ensure quantity is valid
    newQuantity = Math.max(1, parseInt(newQuantity));

    const formData = new FormData();
    formData.append('action', 'update_quantity');
    formData.append('product_id', productId);
    formData.append('quantity', newQuantity);

    fetch('cart.php', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (!response.ok) throw new Error('Network response was not ok');
        return response.json();
    })
    .then(data => {
        if (data.success) {
            updateCartTotal();
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showNotification('Error updating quantity', 'error');
    });
}

function updateCartTotal() {
    const cartTable = document.querySelector('.cart-table');
    if (!cartTable) return;

    const rows = cartTable.querySelectorAll('tbody tr');
    let subtotal = 0;

    rows.forEach(row => {
        const priceCell = row.querySelector('td:nth-child(3)');
        const quantityInput = row.querySelector('.quantity-input');
        
        if (priceCell && quantityInput) {
            const price = parseFloat(priceCell.textContent.replace('$', ''));
            const quantity = parseInt(quantityInput.value) || 1;
            const total = price * quantity;
            
            const totalCell = row.querySelector('td:nth-child(4)');
            if (totalCell) {
                totalCell.textContent = '$' + total.toFixed(2);
            }
            
            subtotal += total;
        }
    });

    // Update summary
    const subtotalElem = document.querySelector('[data-subtotal]');
    const totalElem = document.querySelector('[data-total]');
    const taxAmount = subtotal * 0.1;
    const grandTotal = subtotal + taxAmount;

    if (subtotalElem) {
        subtotalElem.textContent = '$' + subtotal.toFixed(2);
    }
    if (totalElem) {
        totalElem.textContent = '$' + grandTotal.toFixed(2);
    }
}

function addToCart(productId, productName, productPrice) {
    // Create FormData for the request
    const formData = new FormData();
    formData.append('action', 'add_to_cart');
    formData.append('product_id', productId);
    formData.append('product_name', productName);
    formData.append('product_price', productPrice);

    // Find the button that was clicked
    const button = event.target.closest('button');
    const originalText = button ? button.textContent : 'Add to Cart';

    // Fetch request to add item
    fetch('cart.php', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (!response.ok) throw new Error('Network response was not ok');
        return response.json();
    })
    .then(data => {
        if (data.success) {
            // Update cart count
            updateCartCount(data.cart_count);
            
            // Show success notification
            showNotification(`✓ ${productName} added to cart!`, 'success');
            
            // Animate button
            if (button) {
                button.textContent = '✓ Added';
                button.style.backgroundColor = '#28a745';
                setTimeout(() => {
                    button.textContent = originalText;
                    button.style.backgroundColor = '';
                }, 2000);
            }
        } else {
            showNotification('Error adding to cart', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showNotification('Failed to add to cart', 'error');
    });
}

function removeFromCart(productId) {
    const formData = new FormData();
    formData.append('action', 'remove_from_cart');
    formData.append('product_id', productId);

    fetch('cart.php', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (!response.ok) throw new Error('Network response was not ok');
        return response.json();
    })
    .then(data => {
        if (data.success) {
            showNotification('Item removed from cart', 'success');
            setTimeout(() => {
                location.reload();
            }, 500);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showNotification('Error removing item', 'error');
    });
}

function updateCartCount(count) {
    const cartCountBadge = document.querySelector('.cart-count');
    if (cartCountBadge) {
        cartCountBadge.textContent = count;
    }
}

// ==========================================
// NAVIGATION & UI
// ==========================================

function initializeNavigation() {
    // Add active class to current page
    const currentPath = window.location.pathname;
    const navLinks = document.querySelectorAll('.nav-link');

    navLinks.forEach(link => {
        const href = link.getAttribute('href');
        if (currentPath.includes(href)) {
            link.classList.add('active');
        }
    });
}

function initializeProfileDropdown() {
    const profileToggle = document.getElementById('profileToggle');
    const profileMenu = document.getElementById('profileMenu');

    if (!profileToggle || !profileMenu) return;

    // Toggle menu on click
    profileToggle.addEventListener('click', function(e) {
        e.stopPropagation();
        profileToggle.classList.toggle('active');
        profileMenu.classList.toggle('active');
    });

    // Close menu when clicking outside
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.profile-dropdown')) {
            profileToggle.classList.remove('active');
            profileMenu.classList.remove('active');
        }
    });

    // Close menu when clicking menu items
    const menuItems = profileMenu.querySelectorAll('.profile-menu-item');
    menuItems.forEach(item => {
        item.addEventListener('click', function() {
            profileToggle.classList.remove('active');
            profileMenu.classList.remove('active');
        });
    });

    // Keyboard accessibility
    profileToggle.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            profileToggle.click();
        }
    });
}

// ==========================================
// NOTIFICATION SYSTEM
// ==========================================

function showNotification(message, type = 'info') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type}`;
    alertDiv.textContent = message;
    alertDiv.style.position = 'fixed';
    alertDiv.style.top = '80px';
    alertDiv.style.right = '20px';
    alertDiv.style.zIndex = '5000';
    alertDiv.style.maxWidth = '400px';
    alertDiv.style.animation = 'slideIn 0.3s ease-out';

    document.body.appendChild(alertDiv);

    setTimeout(() => {
        alertDiv.style.animation = 'slideOut 0.3s ease-out';
        setTimeout(() => {
            alertDiv.remove();
        }, 300);
    }, 3000);
}

// ==========================================
// FORM VALIDATION
// ==========================================

function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function validatePassword(password) {
    return password.length >= 8;
}

function validateForm(formElement) {
    let isValid = true;
    const inputs = formElement.querySelectorAll('input[required], textarea[required]');

    inputs.forEach(input => {
        if (!input.value.trim()) {
            input.style.borderColor = '#ff6b6b';
            isValid = false;
        } else {
            input.style.borderColor = '';
        }

        // Email validation
        if (input.type === 'email' && !validateEmail(input.value)) {
            input.style.borderColor = '#ff6b6b';
            isValid = false;
        }

        // Password validation
        if (input.type === 'password' && input.hasAttribute('data-validate') && !validatePassword(input.value)) {
            input.style.borderColor = '#ff6b6b';
            isValid = false;
        }
    });

    return isValid;
}

// ==========================================
// ANIMATIONS
// ==========================================

const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }

    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }

    .ripple {
        position: absolute;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.6);
        pointer-events: none;
        animation: rippleAnimation 0.6s ease-out;
    }

    @keyframes rippleAnimation {
        from {
            transform: scale(0);
            opacity: 1;
        }
        to {
            transform: scale(4);
            opacity: 0;
        }
    }

    .btn.active {
        box-shadow: 0 4px 12px rgba(160, 90, 53, 0.4);
    }
`;
document.head.appendChild(style);

// ==========================================
// SMOOTH SCROLLING
// ==========================================

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});
function addToCart(productId, productName, productPrice) {
    const formData = new FormData();
    formData.append('action', 'add_to_cart');
    formData.append('product_id', productId);
    formData.append('product_name', productName);
    formData.append('product_price', productPrice);

    fetch('cart.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Update the count in the header
            document.getElementById('cart-count').innerText = data.cart_count;
            alert(productName + " added to cart!");
        }
    })
    .catch(error => console.error('Error:', error));
}
document.addEventListener('DOMContentLoaded', function() {
    const profileToggle = document.getElementById('profileToggle');
    const profileMenu = document.getElementById('profileMenu');

    if (profileToggle) {
        profileToggle.addEventListener('click', function(e) {
            e.stopPropagation();
            profileToggle.classList.toggle('active');
            profileMenu.classList.toggle('active');
        });
    }

    // Close menu when clicking outside
    document.addEventListener('click', function() {
        if (profileMenu) {
            profileToggle.classList.remove('active');
            profileMenu.classList.remove('active');
        }
    });
});